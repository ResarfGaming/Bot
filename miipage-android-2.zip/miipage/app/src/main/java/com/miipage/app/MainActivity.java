package com.miipage.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "https://mii.samisadev.com";
    private static final String AUTH_DISCORD_PATH = "/auth/discord";

    private WebView webView;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        swipeRefresh = findViewById(R.id.swipeRefresh);

        setupWebView();
        setupNavigation();
        setupSwipeRefresh();

        webView.loadUrl(BASE_URL);
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setAllowFileAccess(false);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                String urlLower = url.toLowerCase();

                if (urlLower.contains("mii.samisadev.com" + AUTH_DISCORD_PATH)) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    return true;
                }

                if (request.getUrl().getHost() != null &&
                        !request.getUrl().getHost().equals("mii.samisadev.com")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, request.getUrl());
                    startActivity(intent);
                    return true;
                }

                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                CookieManager.getInstance().flush();
            }
        });
    }

    private void setupNavigation() {
        findViewById(R.id.btnHome).setOnClickListener(v ->
                webView.loadUrl(BASE_URL));

        findViewById(R.id.btnDashboard).setOnClickListener(v ->
                webView.loadUrl(BASE_URL + "/dashboard"));

        findViewById(R.id.btnSearch).setOnClickListener(v ->
                showSearchDialog());
    }

    private void setupSwipeRefresh() {
        swipeRefresh.setColorSchemeColors(getColor(R.color.pink_dark));
        swipeRefresh.setOnRefreshListener(() -> webView.reload());
    }

    private void showSearchDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_search, null);
        EditText input = dialogView.findViewById(R.id.searchInput);

        AlertDialog dialog = new AlertDialog.Builder(this, R.style.SearchDialog)
                .setView(dialogView)
                .create();

        dialogView.findViewById(R.id.btnGo).setOnClickListener(v -> {
            String username = input.getText().toString().trim();
            if (!username.isEmpty()) {
                dialog.dismiss();
                webView.loadUrl(BASE_URL + "/" + Uri.encode(username));
            } else {
                input.setError("Enter a username");
            }
        });

        dialogView.findViewById(R.id.btnCancel).setOnClickListener(v -> dialog.dismiss());

        input.setOnEditorActionListener((TextView textView, int actionId, KeyEvent event) -> {
            dialogView.findViewById(R.id.btnGo).performClick();
            return true;
        });

        dialog.show();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri data = intent.getData();
        if (data != null && data.toString().toLowerCase().contains("/auth/callback")) {
            webView.loadUrl(data.toString());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
